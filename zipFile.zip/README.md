
# Discord Attendance Bot (Replit Ready)

## Secrets to add:
DISCORD_TOKEN  
LOGIN_LOG_CHANNEL_ID  
LOGOUT_LOG_CHANNEL_ID  
PORT (اختياري 3000)

ثم اضغط Run.
